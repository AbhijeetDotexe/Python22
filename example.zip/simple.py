"""
This is a very simple python file

"""
def myfun():

    """ 
    This is a function to print out two numbers and get a better score using pylint
    	
    """
    first=1
    second=2
    print(first)
    print(second)

myfun()