def cube(n):

    for x in range(n):
        yield x**3



list[cube(10)]
