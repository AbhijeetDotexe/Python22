import datetime
mytime=datetime.time(2,20,30)
print(mytime.min)
print(mytime.hour)
print(mytime)

datetime.time
today=datetime.date.today()
print(today.ctime())
print(datetime.datetime.today())
print(365*21)